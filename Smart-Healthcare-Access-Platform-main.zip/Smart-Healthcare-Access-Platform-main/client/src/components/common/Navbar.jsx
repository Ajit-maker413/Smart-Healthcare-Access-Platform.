import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useUI } from '../../context/UIContext';
import { useSocket } from '../../context/SocketContext';
import api from '../../services/api';
import { BrandMark } from './BrandMark';
import {
  Bell,
  Camera,
  Menu,
  X,
  User,
  LogOut,
  ChevronDown,
  ShieldAlert,
} from 'lucide-react';

const ROLE_NOTIFICATIONS = {
  patient: [
    {
      id: 'p1',
      title: 'Appointment Confirmed',
      message: 'Dr. Mira Patel has confirmed your in-person consultation for tomorrow at 10:30 AM.',
      time: '15m ago',
      unread: true,
      link: '/patient/appointments',
    },
    {
      id: 'p2',
      title: 'Pre-visit Checklist',
      message: 'Please remember to bring photo ID and previous ECG reports to Riverside Medical Center.',
      time: '2h ago',
      unread: true,
      link: '/patient/appointments',
    },
    {
      id: 'p3',
      title: 'Care Summary Ready',
      message: 'Riverside Cardiology published an updated clinical care summary for your records.',
      time: '1d ago',
      unread: false,
      link: '/patient/activity',
    },
  ],
  doctor: [
    {
      id: 'd1',
      title: 'Next Patient: Aarav Mehta',
      message: 'Scheduled at 2:30 PM (In-person, Room C-02) for Initial Cardiology Consultation.',
      time: '10m ago',
      unread: true,
      link: '/doctor/appointments',
    },
    {
      id: 'd2',
      title: 'Reschedule Review Requested',
      message: 'Ananya Iyer requested a routine reschedule for Tue, 10 Nov · 2:30 PM.',
      time: '1h ago',
      unread: true,
      link: '/doctor/schedule',
    },
    {
      id: 'd3',
      title: 'Facility Privileges Confirmed',
      message: 'Riverside Medical Center approved your cardiology clinical affiliations.',
      time: '2d ago',
      unread: false,
      link: '/doctor/affiliations',
    },
  ],
  organization: [
    {
      id: 'o1',
      title: 'Critical Bed Capacity',
      message: 'Monitored bed availability reported at 3 beds remaining in Cardiology Wing.',
      time: '5m ago',
      unread: true,
      link: '/organization/resources',
    },
    {
      id: 'o2',
      title: 'Doctor QR Presence Verified',
      message: 'Dr. Mira Patel scanned badge QR at Main Reception / Cardiology Wing.',
      time: '35m ago',
      unread: true,
      link: '/organization/doctors',
    },
    {
      id: 'o3',
      title: 'Emergency Beep Network Active',
      message: 'Facility listening on 10 km regional perimeter dispatch channel.',
      time: '2h ago',
      unread: false,
      link: '/organization/dashboard',
    },
  ],
  admin: [
    {
      id: 'a1',
      title: 'Practitioner Credentials Pending',
      message: '2 doctor medical licenses awaiting state medical council verification.',
      time: '20m ago',
      unread: true,
      link: '/admin/dashboard',
    },
    {
      id: 'a2',
      title: 'Accreditation Renewal Submitted',
      message: 'Lakeside Specialty Clinic submitted clinical renewal compliance docs.',
      time: '2h ago',
      unread: true,
      link: '/admin/dashboard',
    },
    {
      id: 'a3',
      title: 'Audit Stream Operational',
      message: 'All real-time Socket.io and emergency dispatch nodes verified healthy.',
      time: '1d ago',
      unread: false,
      link: '/admin/dashboard',
    },
  ],
};

export const Navbar = () => {
  const { user, logout, updateUser } = useAuth();
  const { toggleMobileSidebar } = useUI();
  const socketContext = useSocket();
  const incomingEmergency = socketContext?.incomingEmergency || null;
  const navigate = useNavigate();
  const location = useLocation();

  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [photoUploading, setPhotoUploading] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const socket = socketContext?.socket || null;

  const notificationsRef = useRef(null);
  const profileRef = useRef(null);

  // Fetch real notifications from backend with fallback to role defaults
  const fetchRealNotifications = async () => {
    if (!user) return;
    try {
      const res = await api.get('/notifications/my?limit=15');
      if (res.data?.success && Array.isArray(res.data.data)) {
        if (res.data.data.length > 0) {
          const formatted = res.data.data.map((n) => ({
            id: n.notificationId || n._id,
            _id: n._id,
            title: n.title,
            message: n.message,
            time: new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            unread: n.status !== 'READ',
            link: n.actionUrl || '/notifications',
            priority: n.priority,
            type: n.notificationType,
          }));
          setNotifications(formatted);
          return;
        }
      }
    } catch (err) {
      console.warn('Notification fetch warning:', err.message);
    }

    // Role defaults fallback
    if (user?.role && ROLE_NOTIFICATIONS[user.role]) {
      setNotifications(ROLE_NOTIFICATIONS[user.role]);
    } else {
      setNotifications(ROLE_NOTIFICATIONS.patient);
    }
  };

  useEffect(() => {
    fetchRealNotifications();
  }, [user]);

  // Real-time socket notification listener
  useEffect(() => {
    if (!socket) return;

    const handleNewNotification = (newNotif) => {
      const formatted = {
        id: newNotif.notificationId || newNotif._id || `LIVE-${Date.now()}`,
        _id: newNotif._id,
        title: newNotif.title,
        message: newNotif.message,
        time: 'Just now',
        unread: true,
        link: newNotif.actionUrl || '/notifications',
        priority: newNotif.priority,
        type: newNotif.type,
      };

      setNotifications((prev) => [formatted, ...prev.slice(0, 14)]);

    };

    socket.on('notification:new', handleNewNotification);
    socket.on('notification:received', handleNewNotification);

    return () => {
      socket.off('notification:new', handleNewNotification);
      socket.off('notification:received', handleNewNotification);
    };
  }, [socket]);

  // Click outside listener for dropdowns
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (notificationsRef.current && !notificationsRef.current.contains(event.target)) {
        setNotificationsOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target)) {
        setProfileDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter((n) => n.unread).length;
  const hasUnread = unreadCount > 0 || !!incomingEmergency;

  const handleMarkAllRead = async () => {
    try {
      await api.post('/notifications/my/read-all');
    } catch (e) {}
    setNotifications((prev) => prev.map((n) => ({ ...n, unread: false })));
  };

  const handleNotificationClick = async (item) => {
    try {
      if (item._id || (item.id && !item.id.startsWith('p') && !item.id.startsWith('d') && !item.id.startsWith('o') && !item.id.startsWith('a'))) {
        await api.post(`/notifications/${item._id || item.id}/read`);
      }
    } catch (e) {}
    setNotifications((prev) =>
      prev.map((n) => (n.id === item.id ? { ...n, unread: false } : n))
    );
    setNotificationsOpen(false);
    if (item.link) {
      navigate(item.link);
    }
  };

  const roleLabels = {
    patient: 'Patient Portal',
    doctor: 'Doctor Portal',
    organization: 'Hospital Portal',
    admin: 'Administrator',
  };

  const getDashboardRoute = () => {
    if (user?.role === 'doctor') return '/doctor/dashboard';
    if (user?.role === 'organization') return '/organization/dashboard';
    if (user?.role === 'admin') return '/admin/dashboard';
    return '/patient/dashboard';
  };

  const getProfileRoute = () => {
    if (user?.role === 'doctor') return '/doctor/profile';
    if (user?.role === 'patient') return '/patient/profile';
    if (user?.role === 'organization') return '/organization/profile';
    if (user?.role === 'admin' || user?.role === 'web_admin') return '/admin/dashboard';
    return '/patient/profile';
  };

  const isDashboardRoute =
    location.pathname.startsWith('/patient') ||
    location.pathname.startsWith('/doctor') ||
    location.pathname.startsWith('/organization') ||
    location.pathname.startsWith('/admin') ||
    location.pathname.startsWith('/emergency');

  const handleLogout = () => {
    logout();
    setProfileDropdownOpen(false);
    navigate('/login');
  };

  const handleProfilePhotoChange = (event) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    if (!file.type.startsWith('image/')) return;
    if (file.size > 2 * 1024 * 1024) {
      window.alert('Please choose an image smaller than 2 MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = async () => {
      try {
        setPhotoUploading(true);
        const response = await api.put('/auth/me', { avatar: reader.result });
        const updatedUser = response.data?.user || response.data?.data?.user;
        if (updatedUser) updateUser(updatedUser);
      } catch (error) {
        console.error('Failed to update profile photo', error);
        window.alert(error.response?.data?.message || 'Unable to update profile photo.');
      } finally {
        setPhotoUploading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  // Format today's date like "Mon, 09 Nov 2026" / "Wed, 11 Nov 2026"
  const formattedDate = new Intl.DateTimeFormat('en-GB', {
    weekday: 'short',
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date());

  // Generate breadcrumb from path
  const getBreadcrumb = () => {
    if (location.pathname.includes('/patient/dashboard')) return 'Overview';
    if (location.pathname.includes('/search')) return 'Search & Discover';
    if (location.pathname.includes('/doctors')) return 'Find doctors';
    if (location.pathname.includes('/hospitals')) return 'Find hospitals';
    if (location.pathname.includes('/map')) return 'Healthcare map';
    if (location.pathname.includes('/patient/appointments')) return 'Appointments';
    if (location.pathname.includes('/emergency/activate')) return 'Emergency Beep';
    if (location.pathname.includes('/patient/activity')) return 'Care activity';
    if (location.pathname.includes('/patient/profile')) return 'Manage profile';
    if (location.pathname.includes('/doctor/dashboard')) return 'Overview';
    if (location.pathname.includes('/doctor/schedule')) return 'Schedule';
    if (location.pathname.includes('/doctor/appointments')) return 'Appointments';
    if (location.pathname.includes('/doctor/availability')) return 'Availability';
    if (location.pathname.includes('/doctor/profile')) return 'Manage profile';
    if (location.pathname.includes('/doctor/presence')) return 'Presence & Badge';
    if (location.pathname.includes('/doctor/affiliations')) return 'Affiliations';
    if (location.pathname.includes('/doctor')) return 'Doctor Portal';
    if (location.pathname.includes('/organization/profile')) return 'Manage profile';
    if (location.pathname.includes('/organization')) return 'Facility Portal';
    if (location.pathname.includes('/admin')) return 'Admin Portal';
    return 'Portal';
  };

  const getInitials = (name) => {
    if (!name) return 'U';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return name.slice(0, 2).toUpperCase();
  };

  return (
    <header className="bg-white border-b border-[#E2E8F0] sticky top-0 z-40 select-none">
      <div className="w-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Left: Brand Identity & Breadcrumb */}
          <div className="flex items-center space-x-3">
            {/* Mobile Sidebar Hamburger (on dashboard routes) */}
            {isDashboardRoute && (
              <button
                onClick={toggleMobileSidebar}
                className="lg:hidden p-2 text-[#64748B] hover:text-[#111827] hover:bg-[#F1F5F9] rounded-xl transition"
                aria-label="Toggle navigation drawer"
              >
                <Menu className="w-5 h-5" />
              </button>
            )}

            {/* Mobile Menu Toggle (on public routes) */}
            {!isDashboardRoute && (
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="md:hidden p-2 text-[#64748B] hover:text-[#111827] hover:bg-[#F1F5F9] rounded-xl transition"
                aria-label="Toggle navigation menu"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}

            {/* Brand Logo strictly with official Core Brand Palette */}
            <Link to="/" className="flex items-center space-x-2.5 group">
              <BrandMark className="w-8 h-8 shadow-xs group-hover:bg-[#162E93] transition-colors" />
              <div className="flex flex-col">
                <span className="text-base font-black text-[#111827] tracking-tight leading-none">
                  SHAP
                </span>
                <span className="text-[8.5px] font-bold text-[#64748B] tracking-widest uppercase mt-0.5">
                  HEALTHCARE ACCESS PLATFORM
                </span>
              </div>
            </Link>

            {/* Portal Breadcrumb */}
            {isDashboardRoute && user && (
              <div className="hidden md:flex items-center pl-4 ml-3 border-l border-[#E2E8F0] text-xs text-[#64748B] font-medium space-x-1.5">
                <span className="capitalize">{user.role} portal</span>
                <span>/</span>
                <span className="text-[#111827] font-bold">{getBreadcrumb()}</span>
              </div>
            )}
          </div>

          {/* Right: Date, Notifications & User Avatar Pill strictly per Reference Designs */}
          <div className="flex items-center space-x-4">
            {user ? (
              <>
                {/* Date Display (Only visible after login) */}
                <div className="hidden sm:block text-xs font-medium text-[#64748B] tabular-nums">
                  {formattedDate}
                </div>

                {/* Notification Bell (Only visible after login with role-specific notifications) */}
                <div className="relative" ref={notificationsRef}>
                  <button
                    onClick={() => setNotificationsOpen(!notificationsOpen)}
                    className="p-2 text-[#64748B] hover:text-[#111827] hover:bg-[#F1F5F9] rounded-lg transition relative cursor-pointer"
                    aria-label="Notifications"
                  >
                    <Bell className="w-4 h-4" />
                    {hasUnread && (
                      <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#2F2FE4] ring-2 ring-white" />
                    )}
                  </button>

                  {/* Notification Dropdown */}
                  {notificationsOpen && (
                    <div className="absolute right-0 mt-2 w-80 bg-white rounded-xl shadow-modal border border-slate-200/90 p-4 space-y-2.5 z-50 text-xs">
                      <div className="flex items-center justify-between pb-2 border-b border-slate-100 font-bold text-slate-900">
                        <div className="flex items-center space-x-1.5">
                          <span>Notifications</span>
                          {unreadCount > 0 && (
                            <span className="px-1.5 py-0.5 text-[10px] font-bold bg-brand-50 text-brand-700 rounded-md border border-brand-200/60 tabular-nums">
                              {unreadCount}
                            </span>
                          )}
                        </div>
                        {unreadCount > 0 ? (
                          <button
                            onClick={handleMarkAllRead}
                            className="text-[10px] text-brand-600 hover:text-brand-800 font-bold hover:underline cursor-pointer"
                          >
                            Mark all read
                          </button>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-normal">All caught up</span>
                        )}
                      </div>

                      {/* Live Emergency socket alert if any */}
                      {incomingEmergency && (
                        <div
                          onClick={() => {
                            setNotificationsOpen(false);
                            navigate(
                              user?.role === 'organization' ? '/organization/dashboard' : '/map'
                            );
                          }}
                          className="p-2.5 rounded-lg border border-urgent-200 bg-urgent-50 text-urgent-900 cursor-pointer hover:bg-urgent-100/80 transition"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-[10px] uppercase tracking-wider text-urgent-700 flex items-center gap-1">
                              <ShieldAlert className="w-3.5 h-3.5" /> Emergency Beep
                            </span>
                            <span className="text-[9.5px] text-urgent-600 font-bold">Live Alert</span>
                          </div>
                          <p className="text-[10.5px] font-semibold text-urgent-800 mt-1">
                            Incoming dispatch broadcast in your regional coverage zone.
                          </p>
                        </div>
                      )}

                      <div className="space-y-1.5 py-0.5 max-h-80 overflow-y-auto">
                        {notifications.map((item) => (
                          <div
                            key={item.id}
                            onClick={() => handleNotificationClick(item)}
                            className={`p-2.5 rounded-lg border transition cursor-pointer ${
                              item.unread
                                ? 'bg-brand-50/50 border-brand-200/60 hover:bg-brand-50'
                                : 'bg-slate-50/60 border-slate-200/60 hover:bg-slate-100/70'
                            }`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <p className="font-bold text-slate-900 text-[11px] leading-snug">
                                {item.title}
                              </p>
                              <span className="text-[9.5px] text-slate-400 whitespace-nowrap mt-0.5 tabular-nums">
                                {item.time}
                              </span>
                            </div>
                            <p className="text-[10.5px] text-slate-600 mt-1 leading-relaxed">
                              {item.message}
                            </p>
                          </div>
                        ))}
                      </div>

                      <div className="pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px]">
                        <Link
                          to="/notifications"
                          onClick={() => setNotificationsOpen(false)}
                          className="font-bold text-brand-600 hover:text-brand-800 transition flex items-center gap-1 cursor-pointer"
                        >
                          View all notifications &rarr;
                        </Link>
                        <Link
                          to="/notifications?tab=preferences"
                          onClick={() => setNotificationsOpen(false)}
                          className="text-slate-400 hover:text-slate-600 transition cursor-pointer"
                        >
                          Preferences
                        </Link>
                      </div>
                    </div>
                  )}
                </div>

                {/* User Profile Pill strictly per Reference Image 2 */}
                <div className="relative" ref={profileRef}>
                  <button
                    onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                    className="flex items-center space-x-2.5 p-1 pr-2 rounded-full hover:bg-slate-100/80 transition cursor-pointer"
                    aria-label="Open profile menu"
                  >
                    <div className="w-8 h-8 rounded-full bg-[#F0F2FD] text-[#2F2FE4] font-bold text-xs flex items-center justify-center border border-[#C5CAF7] overflow-hidden">
                      {user.avatar ? (
                        <img src={user.avatar} alt="" className="w-full h-full object-cover" />
                      ) : (
                        getInitials(user.name)
                      )}
                    </div>
                    <div className="text-left hidden md:block">
                      <div className="text-xs font-bold text-[#111827] leading-tight truncate max-w-[120px]">
                        {user.role === 'doctor' && !user.name.startsWith('Dr.') ? `Dr. ${user.name}` : user.name}
                      </div>
                      <div className="text-[10px] text-[#64748B] capitalize leading-tight">
                        {user.role === 'patient'
                          ? 'Personal account'
                          : user.role === 'doctor'
                          ? 'Cardiology'
                          : `${user.role} account`}
                      </div>
                    </div>
                    <ChevronDown className="w-3.5 h-3.5 text-[#64748B] hidden md:block" />
                  </button>

                  {/* Dropdown Menu */}
                  {profileDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-52 bg-white rounded-xl shadow-modal border border-[#E2E8F0] py-1.5 z-50 text-xs">
                      <div className="px-4 py-2 border-b border-[#F1F5F9]">
                        <p className="font-bold text-[#111827] truncate">
                          {user.role === 'doctor' && !user.name.startsWith('Dr.') ? `Dr. ${user.name}` : user.name}
                        </p>
                       <p className="text-[10px] text-[#64748B] truncate">{user.email || user.phone}</p>
                      </div>

                      <label className="flex items-center space-x-2 px-4 py-2 text-[#2F2FE4] hover:bg-[#F8FAFC] font-medium cursor-pointer">
                        <Camera className="w-4 h-4 text-[#2F2FE4]" />
                        <span>{photoUploading ? 'Uploading photo…' : 'Change profile photo'}</span>
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/webp"
                          className="hidden"
                          disabled={photoUploading}
                          onChange={handleProfilePhotoChange}
                        />
                      </label>

                      <Link
                        to={getProfileRoute()}
                        onClick={() => setProfileDropdownOpen(false)}
                        className="flex items-center space-x-2 px-4 py-2 text-[#111827] hover:bg-[#F8FAFC] font-medium"
                      >
                        <User className="w-4 h-4 text-[#64748B]" />
                        <span>Manage Profile</span>
                      </Link>

                      <div className="border-t border-[#F1F5F9] my-1" />

                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center space-x-2 px-4 py-2 text-[#DC2626] hover:bg-[#FEF2F2] font-semibold text-left cursor-pointer"
                      >
                        <LogOut className="w-4 h-4 text-[#DC2626]" />
                        <span>Sign Out</span>
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <Link
                  to="/"
                  className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition-colors ${
                    location.pathname === '/'
                      ? 'text-[#2F2FE4] bg-[#F0F2FD] font-bold'
                      : 'text-[#111827] hover:text-[#2F2FE4] hover:bg-[#F8FAFC]'
                  }`}
                >
                  Home
                </Link>
                <Link
                  to="/login"
                  className="px-3.5 py-1.5 text-xs font-bold text-[#111827] hover:text-[#2F2FE4]"
                >
                  Sign In
                </Link>
                <Link
                  to="/register"
                  className="px-3.5 py-1.5 text-xs font-bold bg-[#2F2FE4] text-white rounded-xl hover:bg-[#162E93] shadow-xs"
                >
                  Create Account
                </Link>
              </div>
            )}
          </div>
        </div>
        {/* Mobile Navigation Dropdown for Public Routes */}
        {mobileMenuOpen && !isDashboardRoute && (
          <div className="md:hidden py-3 border-t border-slate-100 space-y-2">
            <Link
              to="/"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 rounded-xl"
            >
              Home
            </Link>
            <div className="flex gap-2">
              <Link
                to="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="flex-1 text-center py-2 text-xs font-semibold text-slate-700 bg-slate-100 rounded-xl"
              >
                Sign In
              </Link>
              <Link
                to="/register"
                onClick={() => setMobileMenuOpen(false)}
                className="flex-1 text-center py-2 text-xs font-semibold text-white bg-[#0B4F9C] rounded-xl"
              >
                Create Account
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;
